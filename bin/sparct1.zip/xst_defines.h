`define FPGA_SYN
`define FPGA_SYN_NO_SPU
`define FPGA_SYN_16TLB
